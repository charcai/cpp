#include<bits/stdc++.h>
using namespace std;
int a[110],x[110],y[110],s1[110],s2[110];
int main(){
	freopen("chorus.in","r",stdin);
	freopen("chorus.out","w",stdout);
	int n,k1=0,k2=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",a+i);
	x[0]=0;		
	for(int i=1;i<=n;i++){
		if(a[i]>x[k1]){
			k1++;
			x[k1]=a[i];
			s1[i]=k1;
		}
		else{
			int l=1,r=k1;
			while(l<r){
				int mid=(l+r)>>1;
				if(x[mid]<a[i])l=mid+1;
				else r=mid;
			}
			x[r]=a[i];
			s1[i]=r;
		}
	}
	y[0]=0;
	for(int i=n;i>=1;i--){
		if(a[i]>y[k2]){
			k2++;
			y[k2]=a[i];
			s2[i]=k2;
		}
		else{
			int l=1,r=k2;
			while(l<r){
				int mid=(l+r)>>1;
				if(y[mid]<a[i])l=mid+1;
				else r=mid;
			}
			y[r]=a[i];
			s2[i]=r;
		}
	}
	int s=0;
	for(int i=1;i<=n;i++)
		s=max(s,s1[i]+s2[i]-1);
	printf("%d\n",n-s);
	return 0;
}