#include<bits/stdc++.h>
using namespace std;
struct hry{
	int x;
	int y;	
}a[5100];
bool cmp(hry a,hry b){
	if(a.x<b.x)return 1;
	else if(a.x>b.x) return 0;
		 else return a.y<=b.y;
}
int f[5100];
int main(){
	freopen("stick.in","r",stdin);
	freopen("stick.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&a[i].x,&a[i].y);
	}
	sort(a+1,a+n+1,cmp);
	int s=0;
	for(int i=1;i<=n;i++){
		int mi=-1,mij;
		for(int j=1;j<=s;j++){
			if(f[j]<=a[i].y&&f[j]>mi){
				mi=f[j];
				mij=j;
			}
		}
		if(mi==-1){s++;f[s]=a[i].y;}
		else f[mij]=a[i].y;
	}
	printf("%d\n",s);
	return 0;
}