#include<bits/stdc++.h>
using namespace std;
int ncases,n;
int suttle,pigweight,fullweight;
int w[502],v[502],mmin[10001];
int main(void){
    freopen("piggy.in","r",stdin);
    freopen("piggy.out","w",stdout);
    ncases=1;
    while( ncases-- ){
        cin >> pigweight >> fullweight;
        suttle = fullweight - pigweight;
        cin >> n;
        for(int i=0; i<10001; i++)    //װ���ĳ�ʼ��
            mmin[i] = -10000000;
        mmin[0] = 0;                 //�������Ҫ
        for(int i=0; i<n; i++){
            cin >> v[i] >> w[i];
            v[i] = -v[i];
        }
        for(int i=0; i<n; i++)
            for(int k=w[i]; k<=suttle; k++)
                mmin[k] = max( mmin[k-w[i]]+v[i],mmin[k] );
        if( mmin[suttle] == -10000000)
            cout << "This is impossible." << endl;
        else
            printf("The minimum amount of money in the piggy-bank is %d.\n",-mmin[suttle]);
    }
    return 0;
}