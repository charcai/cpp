#include<bits/stdc++.h>
using namespace std;
const int N=5e7+5;
int w[N],f[N],t[N];
int n,m,l,wnum,tnum,snum,i,j;

int main(){
	freopen("plan.in","r",stdin);
	freopen("plan.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i){
		scanf("%d%d%d",&wnum,&snum,&tnum);
		for(int j=1;j<=snum;++j){
			++l;
			w[l]=wnum;t[l]=tnum;
		}
	}
	for(int i=1;i<=l;++i){
		for(int j=m;j>=t[i];--j){
			f[j]=max(f[j],f[j-t[i]]+w[i]);
			if(j==0)
				break;
		}
	}
	cout<<f[m]<<endl;
	
	return 0;	
} 
