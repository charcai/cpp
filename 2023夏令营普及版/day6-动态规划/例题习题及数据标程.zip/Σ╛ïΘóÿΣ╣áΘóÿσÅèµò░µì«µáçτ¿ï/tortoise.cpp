#include<bits/stdc++.h>
using namespace std;
int a[510],value[5],dp[51][51][51][51];
int main(){
 	freopen("tortoise.in","r",stdin);
 	freopen("tortoise.out","w",stdout);
 	int n,m;
 	scanf("%d%d",&n,&m);
 	for(int i=1;i<=n;i++)scanf("%d",a+i);
 	for(int i=1;i<=m;i++){
 		int x;
 		scanf("%d",&x);
 		value[x]++;
	 }
	dp[0][0][0][0]=a[1];
	for(int i=0;i<=value[1];i++)
		for(int j=0;j<=value[2];j++)
			for(int k=0;k<=value[3];k++)
				for(int l=0;l<=value[4];l++){
					int x=i+j*2+k*3+l*4+1;
					if(i>0)dp[i][j][k][l]=max(dp[i][j][k][l],dp[i-1][j][k][l]+a[x]);
					if(j>0)dp[i][j][k][l]=max(dp[i][j][k][l],dp[i][j-1][k][l]+a[x]);
					if(k>0)dp[i][j][k][l]=max(dp[i][j][k][l],dp[i][j][k-1][l]+a[x]);
					if(l>0)dp[i][j][k][l]=max(dp[i][j][k][l],dp[i][j][k][l-1]+a[x]);
				 }
	printf("%d\n",dp[value[1]][value[2]][value[3]][value[4]]);
	return 0;
}