#include<bits/stdc++.h>
using namespace std;
int dp[510][510]; 
int a[510],s[510];
int n,k;
void print(int x,int ans){
    if(!x)return;
    for(int i=x;i>=0;i--)
        if(s[x]-s[i-1]>ans||!i){
            print(i,ans);
            printf("%d %d\n",i+1,x);
            break;
        }
}
int main(){
	freopen("book.in","r",stdin);
    freopen("book.out","w",stdout);
    scanf("%d%d",&n,&k);
    for(int i=1;i<=n;i++)scanf("%d",a+i);
    for(int i=1;i<=k;i++)
        for(int j=1;j<=n;j++)
            dp[i][j]=INT_MAX;
    for(int i=1;i<=n;i++)s[i]=s[i-1]+a[i],dp[1][i]=s[i];
    for(int i=2;i<=k;i++)
        for(int j=1;j<=n;j++) 
            for(int k=2;k<=j;k++)  
                dp[i][j]=min(dp[i][j],max(dp[i-1][k-1],s[j]-s[k-1]));
    print(n,dp[k][n]);
    return 0;
}