#include<bits/stdc++.h>
using namespace std;
int v[110][110],dp[55][55][55][55];
int main(){
	freopen("message.in","r",stdin);
	freopen("message.out","w",stdout);
	int m,n;
	scanf("%d%d",&m,&n);
	for(int i=1;i<=m;i++)
		for(int j=1;j<=n;j++)
			scanf("%d",v[i]+j);
	for(int i=1;i<=m;i++)
		for(int j=1;j<=n;j++)
			for(int k=1;k<=m;k++)
				for(int l=1;l<=n;l++){
					if((i-1!=k-1||j!=l)&&i-1>=0&&k-1>=0)dp[i][j][k][l]=max(dp[i][j][k][l],dp[i-1][j][k-1][l]+v[i][j]+v[k][l]);
					if((i!=k-1||j-1!=l)&&j-1>=0&&k-1>=0)dp[i][j][k][l]=max(dp[i][j][k][l],dp[i][j-1][k-1][l]+v[i][j]+v[k][l]);
					if((i-1!=k||j!=l-1)&&i-1>=0&&l-1>=0)dp[i][j][k][l]=max(dp[i][j][k][l],dp[i-1][j][k][l-1]+v[i][j]+v[k][l]);
					if((i!=k||j-1!=l-1)&&j-1>=0&&l-1>=0)dp[i][j][k][l]=max(dp[i][j][k][l],dp[i][j-1][k][l-1]+v[i][j]+v[k][l]);
				}
	printf("%d\n",dp[m][n][m][n]);
	return 0;
}