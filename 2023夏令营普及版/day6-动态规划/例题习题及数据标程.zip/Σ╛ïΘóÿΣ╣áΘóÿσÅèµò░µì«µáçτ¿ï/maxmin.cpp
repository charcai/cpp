#include<bits/stdc++.h>
using namespace std;
int dp[110][110][1100],a[110][110],mx[110][110],n,k;
char ch[1100];
void gjc(int ll,int jj,int ii){
    int nx=ii,ny=jj,dx=ll,dy=jj-1,ax=ll+1,ay=ii,m=0,f=0,lx=0;
    int c[1100],x[1100];
    for(int i=0;i<=1000;i++)c[i]=0;
    for(int i=ay;i>=ax;i--)x[++lx]=int(ch[i])-48;
    for(int i=1;i<=mx[dx][dy];i++)
        for(int j=1;j<=lx;j++){
            c[i+j-1]+=dp[dx][dy][i]*x[j];
        }
    m=max(mx[dx][dy],lx);
    for(int i=1;i<=m;i++){
        c[i+1]+=c[i]/10;
        c[i]%=10;
    }
    while(c[m+1]>0){
    	m++;
    	c[m+1]+=c[m]/10;
    	c[m]%=10;
  	}
  	while(m>1&&c[m]==0)m--;
    if(m>mx[nx][ny])f=1;
    else {
        if(m==mx[nx][ny]){
            for(int i=m;i>=1;i--)
                if(c[i]>dp[nx][ny][i]){f=1;break;}
                else if(c[i]<dp[nx][ny][i])break;
        }
    }
    if(f){
        for(int i=1;i<=m;i++)dp[nx][ny][i]=c[i];
        mx[nx][ny]=m;
    }
}
int main(){
    freopen("maxmin.in","r",stdin);
    freopen("maxmin.out","w",stdout);
    cin>>n>>k;
    while(ch[0]!='\n')ch[0]=getchar();
    for(int h=1;h<=n;h++){
		ch[h]=getchar();
        for(int i=1;i<=h;i++)
            dp[h][0][i]=int(ch[h-i+1])-48;
        mx[h][0]=h;
    }
    for(int j=1;j<=k;j++)
        for(int i=j+1;i<=n;i++)
            for(int l=j;l<i;l++)
                gjc(l,j,i);
    for(int i=mx[n][k];i>=1;i--)
        cout<<dp[n][k][i];
    cout<<endl;
    return 0;
}